MatrixXd m(3,4);
m.resize(NoChange, 5);
cout << "m: " << m.rows() << " rows, " << m.cols() << " cols" << endl;
